# V2 Guides

Questa cartella ospita guide e convenzioni operative specifiche della V2.

| File | Contenuto |
|------|-----------|
| [BACKEND_BOOTSTRAP_AND_VERIFY.md](BACKEND_BOOTSTRAP_AND_VERIFY.md) | Bootstrap locale backend/frontend, auth browser, admin, logistica, sync Easy read-only e sync on demand backend-controlled |

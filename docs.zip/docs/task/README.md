# V2 Task

Questa cartella contiene i task di implementazione da passare a Claude Code.

Regole operative:

- ogni task vive in un file dedicato
- il naming consigliato e `TASK-V2-XXX.md`
- lo stato parte da `Todo`
- Claude Code aggiorna il file durante o al termine del lavoro
- a task completato, Claude Code imposta `Status: Completed` e compila la sezione finale di esecuzione

Task registrati:

- `TASK-V2-001-bootstrap-backend.md` - completato
- `TASK-V2-002-hardening-verifica-backend.md` - completato
- `TASK-V2-003-bootstrap-db-interno.md` - completato
- `TASK-V2-004-browser-auth-and-role-routing.md` - completato
- `TASK-V2-005-admin-access-management.md` - completato
- `TASK-V2-006-ui-navigation-refactor.md` - todo

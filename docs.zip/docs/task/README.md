# V2 Task

Questa cartella contiene i task di implementazione da passare a Claude Code.

Regole operative:

- ogni task vive in un file dedicato
- il naming consigliato e `TASK-V2-XXX.md`
- lo stato parte da `Todo`
- Claude Code aggiorna il file durante o al termine del lavoro
- a task completato, Claude Code imposta `Status: Completed` e compila la sezione finale di esecuzione

Task registrati:

- `TASK-V2-001-bootstrap-backend.md` - completato
- `TASK-V2-002-hardening-verifica-backend.md` - completato
- `TASK-V2-003-bootstrap-db-interno.md` - completato
- `TASK-V2-004-browser-auth-and-role-routing.md` - completato
- `TASK-V2-005-admin-access-management.md` - completato
- `TASK-V2-006-ui-navigation-refactor.md` - completato
- `TASK-V2-007-bootstrap-sync-clienti.md` - completato (bootstrap storico)
- `TASK-V2-008-hardening-backend-verifica-and-sync-scaffolding.md` - completato
- `TASK-V2-009-easy-schema-explorer-and-catalog.md` - completato
- `TASK-V2-010-sync-clienti-reale.md` - completato
- `TASK-V2-011-sync-destinazioni.md` - completato
- `TASK-V2-012-core-clienti-destinazioni.md` - completato
- `TASK-V2-013-ui-clienti-destinazioni.md` - completato
- `TASK-V2-014-sync-on-demand-clienti-destinazioni.md` - completato
- `TASK-V2-015-destinazione-principale-derivata.md` - todo
- `TASK-V2-016-ui-scroll-colonne-clienti-destinazioni.md` - todo
- `TASK-V2-017-sidebar-navigation-contestuale.md` - todo

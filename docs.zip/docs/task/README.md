# V2 Task

Questa cartella contiene i task di implementazione da passare a Claude Code.

Regole operative:

- ogni task vive in un file dedicato
- il naming consigliato e `TASK-V2-XXX.md`
- lo stato parte da `Todo`
- Claude Code aggiorna il file durante o al termine del lavoro
- a task completato, Claude Code imposta `Status: Completed` e compila la sezione finale di esecuzione
- ogni task deve dichiarare esplicitamente il livello di verifica richiesto:
  - `Mirata`
  - `Full suite / milestone`
- ogni task che introduce o modifica una vista UI deve dichiarare esplicitamente il comportamento di refresh:
  - nessun refresh on demand
  - refresh semantico backend riusato
  - refresh semantico backend introdotto o modificato
- di default Claude aggiorna solo il task chiuso; il riallineamento di roadmap, overview, indici e guide trasversali viene fatto successivamente da Codex o da un revisore documentale

Task registrati:

- `TASK-V2-001-bootstrap-backend.md` - completato
- `TASK-V2-002-hardening-verifica-backend.md` - completato
- `TASK-V2-003-bootstrap-db-interno.md` - completato
- `TASK-V2-004-browser-auth-and-role-routing.md` - completato
- `TASK-V2-005-admin-access-management.md` - completato
- `TASK-V2-006-ui-navigation-refactor.md` - completato
- `TASK-V2-007-bootstrap-sync-clienti.md` - completato (bootstrap storico)
- `TASK-V2-008-hardening-backend-verifica-and-sync-scaffolding.md` - completato
- `TASK-V2-009-easy-schema-explorer-and-catalog.md` - completato
- `TASK-V2-010-sync-clienti-reale.md` - completato
- `TASK-V2-011-sync-destinazioni.md` - completato
- `TASK-V2-012-core-clienti-destinazioni.md` - completato
- `TASK-V2-013-ui-clienti-destinazioni.md` - completato
- `TASK-V2-014-sync-on-demand-clienti-destinazioni.md` - completato
- `TASK-V2-015-destinazione-principale-derivata.md` - completato
- `TASK-V2-016-ui-scroll-colonne-clienti-destinazioni.md` - completato
- `TASK-V2-017-sidebar-navigation-contestuale.md` - completato
- `TASK-V2-018-sync-articoli-reale.md` - completato
- `TASK-V2-019-core-articoli.md` - completato
- `TASK-V2-020-ui-articoli.md` - completato
- `TASK-V2-021-sync-on-demand-articoli.md` - completato
- `TASK-V2-022-famiglia-articoli.md` - completato
- `TASK-V2-023-ui-famiglia-articoli.md` - completato
- `TASK-V2-024-filtro-famiglia-articoli.md` - completato
- `TASK-V2-025-ui-tabella-famiglia-articoli.md` - completato
- `TASK-V2-026-gestione-famiglie-articoli.md` - completato
- `TASK-V2-027-flag-considera-in-produzione-famiglie.md` - completato
- `TASK-V2-028-sync-produzioni-attive.md` - completato
- `TASK-V2-029-sync-produzioni-storiche.md` - completato
- `TASK-V2-030-core-produzioni-bucket-e-stato.md` - completato
- `TASK-V2-031-ui-produzioni.md` - completato
- `TASK-V2-032-sync-on-demand-produzioni.md` - completato
- `TASK-V2-033-forza-completata-produzioni.md` - completato
- `TASK-V2-034-performance-produzioni-active-default.md` - completato
- `TASK-V2-035-filtri-e-ricerca-produzioni.md` - completato
- `TASK-V2-036-sync-mag-reale.md` - completato
- `TASK-V2-037-core-inventory-positions.md` - completato
- `TASK-V2-038-giacenza-articoli-nel-dettaglio-ui.md` - completato
- `TASK-V2-039-refresh-sequenziale-articoli-e-giacenza.md` - completato
- `TASK-V2-040-sync-righe-ordine-cliente.md` - completato
- `TASK-V2-041-core-ordini-cliente.md` - completato
- `TASK-V2-042-commitments-cliente.md` - completato
- `TASK-V2-043-commitments-produzione.md` - completato
- `TASK-V2-044-customer-set-aside.md` - completato
- `TASK-V2-045-set-aside-articoli-nel-dettaglio-ui.md` - completato
- `TASK-V2-046-refresh-sequenziale-articoli-giacenza-e-set-aside.md` - completato
- `TASK-V2-047-refresh-articoli-con-ordini-per-set-aside.md` - completato
- `TASK-V2-048-allineamento-operativo-righe-ordine-cliente.md` - completato
- `TASK-V2-049-core-availability.md` - completato
- `TASK-V2-050-availability-e-commitments-articoli-nel-dettaglio-ui.md` - completato
- `TASK-V2-051-refresh-sequenziale-articoli-con-availability.md` - completato
- `TASK-V2-052-hardening-normalizzazione-article-code-cross-source.md` - completato
- `TASK-V2-053-refresh-sequenziale-articoli-con-commitments.md` - completato
- `TASK-V2-054-refresh-semantici-backend.md` - completato
- `TASK-V2-055-criticita-articoli-v1.md` - completato
- `TASK-V2-056-refinement-ui-criticita-articoli.md` - completato
- `TASK-V2-057-toggle-considera-in-produzione-criticita.md` - completato
- `TASK-V2-058-refresh-criticita-collegato-a-refresh-articoli.md` - completato
- `TASK-V2-059-hardening-criticita-join-article-code.md` - completato
- `TASK-V2-060-perimetro-criticita-solo-articoli-presenti.md` - completato
- `TASK-V2-061-separazione-ricerca-codice-e-descrizione-articoli.md` - todo
